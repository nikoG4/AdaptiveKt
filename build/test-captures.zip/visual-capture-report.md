﻿# Admin Demo Visual Capture Report

Generated at: 2026-05-22 16:57:00Z
Command: .\\tools\\capture-admin-demo.ps1 -OutputDir build\visual-captures -ZipPath build\test-captures.zip

## Capture matrix

| Screen | Breakpoint | Width | Height | File | Size (bytes) |
|---|---|---|---|---|---|
| dashboard | compact | 420 | 900 | compact/dashboard-compact-420x900.png | 20647 |
| employees | compact | 420 | 900 | compact/employees-compact-420x900.png | 27283 |
| products | compact | 420 | 900 | compact/products-compact-420x900.png | 25856 |
| invoices | compact | 420 | 900 | compact/invoices-compact-420x900.png | 25851 |
| settings | compact | 420 | 900 | compact/settings-compact-420x900.png | 20479 |
| dashboard | medium | 720 | 900 | medium/dashboard-medium-720x900.png | 30326 |
| employees | medium | 720 | 900 | medium/employees-medium-720x900.png | 38651 |
| products | medium | 720 | 900 | medium/products-medium-720x900.png | 36891 |
| invoices | medium | 720 | 900 | medium/invoices-medium-720x900.png | 36810 |
| settings | medium | 720 | 900 | medium/settings-medium-720x900.png | 30631 |
| dashboard | expanded | 1000 | 900 | expanded/dashboard-expanded-1000x900.png | 35429 |
| employees | expanded | 1000 | 900 | expanded/employees-expanded-1000x900.png | 41706 |
| products | expanded | 1000 | 900 | expanded/products-expanded-1000x900.png | 40173 |
| invoices | expanded | 1000 | 900 | expanded/invoices-expanded-1000x900.png | 39765 |
| settings | expanded | 1000 | 900 | expanded/settings-expanded-1000x900.png | 35785 |
| dashboard | large | 1440 | 900 | large/dashboard-large-1440x900.png | 39594 |
| employees | large | 1440 | 900 | large/employees-large-1440x900.png | 47484 |
| products | large | 1440 | 900 | large/products-large-1440x900.png | 43765 |
| invoices | large | 1440 | 900 | large/invoices-large-1440x900.png | 44829 |
| settings | large | 1440 | 900 | large/settings-large-1440x900.png | 42454 |

## Output

- Output directory: build\visual-captures
- Manifest: build\visual-captures/manifest.json
- Report: build\visual-captures/visual-capture-report.md
- Zip: build\test-captures.zip

## Notes

- El script usa AWT Robot para capturar la ventana dedicada de admin-demo.
- Requiere una sesión gráfica real y una pantalla activa.
- No captura la pantalla completa ni otra app.
- Si alguna captura falla, el script aborta por defecto.
